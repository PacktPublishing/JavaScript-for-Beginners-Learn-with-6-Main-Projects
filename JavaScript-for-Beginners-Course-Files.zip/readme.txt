Each of these .html files are from the final result in each video.
Each file is paired with a JavaScript for Beginners video.
